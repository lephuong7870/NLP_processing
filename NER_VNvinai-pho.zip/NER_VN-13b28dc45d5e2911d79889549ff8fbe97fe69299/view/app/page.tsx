import Component from "../vietnamese-ner"

export default function Page() {
  return <Component />
}
